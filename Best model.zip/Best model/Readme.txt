Best performing model is Deep Neural Network using title and abstracts of research articles.


********************************************************************
LSR_update_data.py is the final code which trains the model, and can be used to make predictions for the next Living Systematic Review update.

Title_and_Abstract.csv file has the data for training and validating the model.

LSR_update_data.csv file is only a sample file read by the code for prediction. This file should be replaced by the actual file downloaded from Covidence for the living systematic review update of:

# The WWARN Clinical Trials Library: A systematically constructed database of clinical efficacy trials of human-infecting Plasmodium Public registration Updates (https://osf.io/fpx9t) #

*******************************************************************

For 10 fold cross validation performance of this model, see DNN_TIAB.py in 'Models' folder